const Role = {
    ADMIN: "Admin", 
    STAFF: "Staff",
    CUSTOMER: "Customer"
}

module.exports = {Role};