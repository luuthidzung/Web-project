import React from 'react';
import './style.scss';

export default function ({name}) {


    return (
        <p className="PersonName">{name}</p>
    )
}