import React from 'react';
import './style.scss';

export default function ({genre}) {


    return (
        <p className="Genre">{genre}</p>
    )
}