import React from 'react';
import './style.scss';

export default function() {
    return (
        <div>
            hihi
        </div>
    )
}